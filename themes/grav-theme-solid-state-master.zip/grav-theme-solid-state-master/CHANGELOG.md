# v1.0.2
## 04/12/2016

1. [](#improved)
    * Updated fontawesome

# v1.0.1
## 02/05/2016

1. [](#bugfix)
    * Renamed main plugin class and yaml file to be shown in Admin panel
    * Removed useless code from yaml definition file

# v1.0.0
## 10/25/2015

1. [](#new)
    * Initial Release
