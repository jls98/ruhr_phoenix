---
title: Home
background_image: bg.jpg
content:
    items: @self.modular
    order:
        by: default
        dir: asc
        custom:
            - _1_banner
            - _2_wrapper
---