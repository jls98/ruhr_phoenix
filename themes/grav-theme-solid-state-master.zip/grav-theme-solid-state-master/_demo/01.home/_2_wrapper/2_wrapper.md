---
sections:
    one:
        type: section1
        style: style1
        image: pic01.jpg
        title: "Magna arcu feugiat" 
        body: "Lorem ipsum dolor sit amet, etiam lorem adipiscing elit. Cras turpis ante, nullam sit amet turpis non, sollicitudin posuere urna. Mauris id tellus arcu. Nunc vehicula id nulla dignissim dapibus. Nullam ultrices, neque et faucibus viverra, ex nulla cursus."
        button_url: #
        button_caption: Learn more
    two:
        type: section1
        style: style2
        image: pic02.jpg
        title: "Tempus adipiscing" 
        body: "Lorem ipsum dolor sit amet, etiam lorem adipiscing elit. Cras turpis ante, nullam sit amet turpis non, sollicitudin posuere urna. Mauris id tellus arcu. Nunc vehicula id nulla dignissim dapibus. Nullam ultrices, neque et faucibus viverra, ex nulla cursus."
        button_url: #
        button_caption: Learn more
    three:
        type: section1
        style: style3
        image: pic03.jpg
        title: "Nullam dignissim" 
        body: "Lorem ipsum dolor sit amet, etiam lorem adipiscing elit. Cras turpis ante, nullam sit amet turpis non, sollicitudin posuere urna. Mauris id tellus arcu. Nunc vehicula id nulla dignissim dapibus. Nullam ultrices, neque et faucibus viverra, ex nulla cursus."
        button_url: #
        button_caption: Learn more
    four:
        type: section2
        style: style1
        body: |
            Nullam dignissim
            ------------------
            Lorem ipsum dolor sit amet, etiam lorem adipiscing elit. Cras turpis ante, nullam sit amet turpis non, sollicitudin posuere urna. Mauris id tellus arcu. Nunc vehicula id nulla dignissim dapibus. Nullam ultrices, neque et faucibus viverra, ex nulla cursus.
        features:
            one:
                image: pic04.jpg
                title: Sed feugiat lorem
                body: Lorem ipsum dolor sit amet, consectetur adipiscing vehicula id nulla dignissim dapibus ultrices.
                button_url: #
                button_caption: Learn more
            two:
                image: pic05.jpg
                title: Nisl placerat
                body: Lorem ipsum dolor sit amet, consectetur adipiscing vehicula id nulla dignissim dapibus ultrices.
                button_url: #
                button_caption: Learn more
            three:
                image: pic06.jpg
                title: Ante fermentum
                body: Lorem ipsum dolor sit amet, consectetur adipiscing vehicula id nulla dignissim dapibus ultrices.
                button_url: #
                button_caption: Learn more
            four:
                image: pic07.jpg
                title: Fusce consequat
                body: Lorem ipsum dolor sit amet, consectetur adipiscing vehicula id nulla dignissim dapibus ultrices.
                button_url: #
                button_caption: Learn more
        button_url: #
        button_caption: Browse All
---